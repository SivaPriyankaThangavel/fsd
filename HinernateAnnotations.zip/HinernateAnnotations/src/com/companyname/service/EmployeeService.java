package com.companyname.service;

import com.companyname.entity.Employee;

public interface EmployeeService {

	public void addEmployee(Employee e);
	public void showEmployee();
	public void editEmployee();
	public void deleteEmployee();
}
