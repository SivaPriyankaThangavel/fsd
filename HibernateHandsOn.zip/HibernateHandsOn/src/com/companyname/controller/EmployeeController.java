package com.companyname.controller;

import java.util.ArrayList;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.companyname.entity.Account;
import com.companyname.entity.CreditCard;
import com.companyname.entity.Employee;

public class EmployeeController {

	public static void main(String[] args) {
		
		Configuration configuration=new Configuration().configure("resources/hibernate.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
		Employee e=new Employee();
		e.setEmployeeId(101);
		e.setEmployeeName("Gavin");
		e.setEmailId("gavin@gmail.com");
		e.setContactNumber("9876543210");

		CreditCard cc=new CreditCard();
		cc.setCreditCardNumber("4455 6655 3322 1122");
		cc.setExpiryDate(new Date("19/03/2019"));
		cc.setCvv((short)123);
		cc.setNameOnTheCard("Gavin King");
		cc.setEmployeeId(101);
		cc.setEmployee(e);
		
		Account acc1=new Account();
		Account acc2=new Account();
		Account acc3=new Account();
		
		acc1.setAccountNumber(2456879123L);
		acc1.setAccountHolderName("Gavin");
		acc1.setEmployee(e);
		
		acc2.setAccountNumber(4256879123L);
		acc2.setAccountHolderName("Gavin");
		acc2.setEmployee(e);
		
		acc3.setAccountNumber(5426879123L);
		acc3.setAccountHolderName("Gavin");
		acc3.setEmployee(e);
		
		ArrayList<Account> accountList=new ArrayList<>();
		accountList.add(acc1);
		accountList.add(acc2);
		accountList.add(acc3);
		
		e.setAccount(accountList);
		
		session.save(e);
		session.save(cc);
		session.save(acc1);
		session.save(acc2);
		session.save(acc3);
		
		
		transaction.commit();
		
		System.out.println("Data has been successfully insterted.");
		
		session.close();

	}

}
